# Marathi Brain Challenge — V12

V12 focuses on a clean, professional mobile shell and rewards UI.

## V12 changes
- Removed the app-owned bottom navigation bar completely. Android's own Home/Back/Multitasking navigation remains untouched.
- Header is now a fixed app chrome positioned below the Android status-bar safe area. It stays visible while content scrolls underneath it.
- Main content starts below the fixed header and ends above the Android navigation safe area.
- Redesigned logo: clean navy/gold brain + open-book mark, readable at small icon sizes.
- Rewards Center now has polished tabs: Overview, Badges, Redeem.
- About App entry now clearly identifies the full About section.
- Existing Firebase/AdMob V11 integration is retained.

## Build
Use `BUILD-WORKFLOW-V12.yml` as `.github/workflows/build-apk.yml` and keep the wrapper ZIP filename exactly: `marathi_brain_challenge_one_upload_apk_builder_v12.zip`.

## Firebase / AdMob
The Firebase web configuration remains placeholder unless you supply your real Firebase Web App config. AdMob uses official Google test IDs until replaced with your production IDs.

## Android compatibility
Workflow targets SDK 36 and min SDK 24. Native WindowInsets handling is used so app content avoids status/navigation system areas.
