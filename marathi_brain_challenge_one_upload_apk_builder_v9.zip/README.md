# मराठी बुद्धीचाचणी — V9

## V9 मुख्य सुधारणा
- नवीन शांत, स्पष्ट Navy + Gold + White app branding.
- नवीन **BRAIN QUIZ** app logo.
- Android 15+ Edge-to-Edge system bar overlap fix: status bar, navigation bar आणि gesture area मध्ये app content अडकणार नाही.
- Android system **Home / Back / Multitasking buttons OS चेच राहतात**; app त्यांना बदलत नाही. त्यांच्यावर app content overlap होऊ नये म्हणून native WindowInsets handling जोडले आहे.
- Android Back button: screen history नुसार मागे जाते; Home screen वर app बंद करण्याऐवजी app minimize होते.
- प्रत्येक internal screen साठी मोठा, स्पष्ट आणि consistent **‹ Back** button.
- नवीन V9 app icon आणि Capacitor native icon/splash generation.
- Capacitor 8 + Android API 24 minimum + compile/target API 36.
- Firebase Web SDK: Anonymous Auth + Firestore questions/current_affairs + scores integration कायम.
- **महत्त्वाचे:** या package मध्ये तुमच्या Firebase project ची वास्तविक credentials/google-services.json उपलब्ध नसल्यामुळे ती बनावट भरलेली नाहीत. `player/firebase-config.js` मध्ये तुमच्या Firebase Web App config चे values भरल्यावर online Firebase data चालेल.
- AdMob native integration: `@capacitor-community/admob` v8.
- Build मध्ये Google चे **official test AdMob App ID + Rewarded test ad unit** वापरले आहेत, त्यामुळे development testing करता येईल.
- Production/Play Store release आधी तुमचा AdMob App ID आणि Rewarded Ad Unit ID बदलणे आवश्यक.
- Rewarded Ad पूर्ण झाल्यावर +20 Coins मिळतात.

## AdMob test IDs
- Test App ID: `ca-app-pub-3940256099942544~3347511713`
- Test Rewarded Ad Unit: `ca-app-pub-3940256099942544/5224354917`

## Firebase setup
1. Firebase Console मध्ये Android/Web app तयार करा.
2. Android package: `com.marathibrainchallenge.app`
3. Web App config मधील values `player/firebase-config.js` मध्ये भरा.
4. Anonymous Authentication enable करा.
5. Firestore Database तयार करून `firebase/firestore.rules` deploy करा.
6. Current Affairs साठी `firebase/functions/` deploy करा.

Native Android Firebase Analytics/Crashlytics जोडायचे असल्यास Firebase Console मधून `google-services.json` download करून native Android project मध्ये ठेवणे आवश्यक आहे. या one-upload builder मध्ये वास्तविक project credentials नसल्याने तो भाग optional ठेवला आहे.

## GitHub Build
Repository root मध्ये हे नाव असले पाहिजे:
`marathi_brain_challenge_one_upload_apk_builder_v9.zip`

`.github/workflows/build-apk.yml` साठी package सोबत दिलेली `BUILD-WORKFLOW-V9.yml` फाईल वापरा.

## महत्त्वाची सुरक्षा नोंद
Coins/score client-side localStorage वर असल्याने ते real-money reward system म्हणून सुरक्षित नाही. Production cash/redeem rewards साठी server-side validation/SSV आवश्यक आहे.
