# मराठी बुद्धीचाचणी — V17 UI/Branding Fix

या build मध्ये:
- नवीन branded app icon + splash screen (`assets/icon.png`, `assets/splash.png`)
- header खालील duplicate status-bar gap काढला
- Android bottom navigation safe-area साठी स्वतंत्र white shield + scroll padding
- light professional home/hero styling
- splash transition अधिक जलद
- About मध्ये Version **16.0.0**
- Android `versionCode 16` / `versionName 16.0.0`

GitHub Actions मधून `BUILD-WORKFLOW-V17.yml` manual run केल्यावर Debug APK artifact मिळेल.
