# Marathi Brain Challenge — V14

V14 is the corrected professional layout build.

- Removed the in-app bottom navigation bar completely. Android system navigation remains untouched.
- Header is light/white and sticky. It stays below the Android status area and content scrolls underneath it.
- Bottom safe-area padding prevents final content from appearing under the Android navigation/taskbar area.
- Rewards Center uses Overview / Badges / Redeem tabs.
- Premium navy/gold Brain Quiz logo included.
- About App screen retained and presented as a normal scrollable screen.
- Native WindowInsets handling remains enabled for Android edge-to-edge devices.
- AdMob test integration remains from V12.

Important: Firebase real project credentials and production AdMob IDs are not included unless supplied separately.
