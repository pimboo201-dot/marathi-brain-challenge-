# Marathi Brain Challenge V17 (Fixed)

GitHub-based APK build प्रोजेक्ट — PC लागत नाही, सर्व build GitHub Actions वर होते.

## या Fixed आवृत्तीत काय बदलले?
1. **Build workflow दुरुस्त केला** — जुना workflow रिपॉझिटरीत `marathi_brain_challenge_fixed_v17.zip` नावाची एक "wrapper" zip शोधत होता, जी आत `v2-project.zip` अपेक्षित होती. ती फाईल कधीच रिपॉझिटरीत नव्हती, त्यामुळे build पहिल्याच स्टेपला (`Extract V17 wrapper ZIP`) fail व्हायचा. आता workflow थेट repo मधल्या `player/` आणि `assets/` फोल्डरमधून build करतो — कोणतीही wrapper zip लागत नाही.
2. **Firebase deploy workflow तशीच दुरुस्त केली** — तीच wrapper-zip समस्या होती.
3. **Secure quiz submission (submitQuiz) प्रत्यक्षात कधीच वापरले जात नव्हते** — `player/app.js` मध्ये `serverQuiz` हा flag कायम `false` राहायचा, त्यामुळे README मध्ये सांगितलेले "server-side scoring" प्रत्यक्षात कधीच चालत नव्हते, आणि प्रत्येक वेळी client थेट `scores` collection मध्ये लिहायचा प्रयत्न करायचा — जो Firestore Rules मुळे नेहमी नाकारला जायचा (console मध्ये silent error). आता Firestore मधून आलेल्या (खऱ्या document id असलेल्या) प्रश्नांसाठी क्विझ योग्य प्रकारे `submitQuiz` Cloud Function द्वारे सुरक्षितपणे score/coins mark करते; स्थानिक demo प्रश्नांसाठी नेहमीप्रमाणे local scoring चालू राहते.

## Repo Structure (आता सोपी/सपाट रचना)
```
.github/workflows/build-apk.yml        ← APK build workflow
.github/workflows/deploy-firebase.yml  ← Firebase Functions/Rules deploy workflow
player/    ← Android APK मध्ये पॅक होणारे web app (Quiz)
admin/     ← Admin web app (वेगळ्या static host वर होस्ट करायचे, उदा. Firebase Hosting)
assets/    ← App icon/splash generate करण्यासाठी लागणारे assets
firebase/  ← Cloud Functions + Firestore Rules
firebase.json
```

## Firebase setup
1. `player/firebase-config.js` आणि `admin/firebase-config.js` मध्ये Firebase Web App config आधीच टाकलेले आहे (या पॅकेजमध्ये).
2. Firebase Console मध्ये Anonymous Authentication (Player साठी) आणि Email/Password Authentication (Admin साठी) enable करा.
3. `admins/<ADMIN_UID>` डॉक्युमेंट `{ "role": "admin" }` सह तयार करा.
4. Rules + Functions deploy करण्यासाठी खाली दिलेला GitHub Actions मार्ग वापरा (PC शिवाय), किंवा स्थानिक PC वरून: `firebase deploy --only firestore:rules,functions`

## Android APK Build (GitHub Actions)
1. हे संपूर्ण फोल्डर (आतले सर्व content, हा README सकट) तुमच्या GitHub repository च्या **root** मध्ये टाका/commit करा — `.github/workflows/` फोल्डर तसाच ठेवा.
2. GitHub वर **Actions → Build Marathi Brain Challenge APK V17 → Run workflow** उघडा आणि run करा.
3. Build यशस्वी झाल्यावर, त्याच run च्या पानावर खाली **Artifacts** मध्ये `Marathi-Brain-Challenge-APK-V17` नावाची फाईल डाउनलोड करा — त्यात `app-debug.apk` असेल.
4. हा एक **Debug APK** आहे (टेस्टिंगसाठी). Play Store वर प्रकाशित करण्यापूर्वी: (अ) खरा AdMob App ID / Rewarded Ad Unit ID वापरा (सध्या Google चे अधिकृत Test ID आहेत), (ब) Release/signed build तयार करा.

## Firebase Backend Deploy (GitHub Actions, PC शिवाय)
1. Firebase Console → Project settings → Service accounts → नवीन private key JSON generate करा.
2. GitHub repo → Settings → Secrets and variables → Actions मध्ये हे दोन secrets टाका:
   - `FIREBASE_PROJECT_ID` = तुमचा Firebase Project ID
   - `FIREBASE_SERVICE_ACCOUNT_JSON` = वरच्या JSON फाईलमधील संपूर्ण मजकूर
3. **Actions → Deploy Firebase Backend V17 → Run workflow** चालवा.

### महत्त्वाचे
Service-account JSON कधीही chat, README, किंवा repository च्या normal फाईलमध्ये paste करू नका — फक्त GitHub Actions Secrets मध्ये ठेवा.


## V17.1 fixes
- GitHub Actions now uses Node.js 22 for the Capacitor 8 toolchain.
- Firebase Functions deployment uses `npm install` because this repository does not ship a generated `package-lock.json`; `npm ci` would fail immediately.
- Secure quiz submission now rejects oversized (>5) and duplicate question references.
- JavaScript and workflow syntax was validated locally.


## V18 branding and textbook-aligned question update
- App icon and web branding use the user-supplied "मराठी बुद्धीचाचणी" logo artwork.
- Native splash asset uses the supplied poster artwork.
- `player/balbharati-bank.js` contains 1,800 original, class-wise questions (Classes 1–12; 6 subjects; 5 topic chapters; 5 questions per chapter).
- Questions are aligned to broad textbook learning areas and reference the official eBalbharati library at https://books.ebalbharati.in/; textbook prose is not copied verbatim.
- Firebase deployment remains Spark-compatible: this package does not require Cloud Functions for the player build.
