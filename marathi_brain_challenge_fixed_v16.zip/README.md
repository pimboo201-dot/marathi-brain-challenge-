# Marathi Brain Challenge — V15

V15 is the corrected professional layout build.

- Removed the in-app bottom navigation bar completely. Android system navigation remains untouched.
- Header is light/white and sticky. It stays below the Android status area and content scrolls underneath it.
- Bottom safe-area padding prevents final content from appearing under the Android navigation/taskbar area.
- Rewards Center uses Overview / Badges / Redeem tabs.
- Premium navy/gold Brain Quiz logo included.
- About App screen retained and presented as a normal scrollable screen.
- Native WindowInsets handling remains enabled for Android edge-to-edge devices.
- AdMob test integration remains from V12.

Important: Firebase real project credentials and production AdMob IDs are not included unless supplied separately.


V15 UI fix: added a fixed white system-safe top shield above the app header so Android status bar remains clean while content scrolls behind the fixed header.


## V16 UI / startup fixes
- Fixed the large blank gap above the home hero by removing the duplicated Android status-bar inset from the content offset.
- Android WindowInsets are converted from physical pixels to WebView CSS/dp pixels before being exposed to the page.
- Reduced the in-app web splash to a short 180 ms paint delay.
- Changed the home hero from heavy navy to a light blue/white professional layout while retaining navy/gold brand accents.
- Kept Android system navigation/status bars light and safe-area aware.
