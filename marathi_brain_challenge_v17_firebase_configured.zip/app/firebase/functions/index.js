const { onSchedule } = require('firebase-functions/v2/scheduler');
const { logger } = require('firebase-functions');
const admin = require('firebase-admin');
const { XMLParser } = require('fast-xml-parser');

admin.initializeApp();
const db = admin.firestore();

const FEEDS = [
  'https://news.google.com/rss?hl=mr&gl=IN&ceid=IN:mr',
  'https://news.google.com/rss/headlines/section/topic/NATION?hl=mr&gl=IN&ceid=IN:mr',
  'https://news.google.com/rss/headlines/section/topic/SPORTS?hl=mr&gl=IN&ceid=IN:mr'
];

function cleanTitle(value='') {
  return String(value).replace(/\s+-\s+[^-]+$/, '').trim();
}

async function fetchFeed(url) {
  const response = await fetch(url, { headers: { 'User-Agent': 'MarathiBrainChallenge/6.0' } });
  if (!response.ok) throw new Error(`RSS ${response.status}`);
  const xml = await response.text();
  const parser = new XMLParser({ ignoreAttributes: false });
  const parsed = parser.parse(xml);
  const items = parsed?.rss?.channel?.item || [];
  return (Array.isArray(items) ? items : [items]).map(x => ({
    title: cleanTitle(x.title), link: x.link || '', pubDate: x.pubDate || ''
  })).filter(x => x.title);
}

exports.updateCurrentAffairs = onSchedule({ schedule: 'every 6 hours', timeZone: 'Asia/Kolkata', region: 'asia-south1' }, async () => {
  const all = [];
  for (const feed of FEEDS) {
    try { all.push(...await fetchFeed(feed)); } catch (e) { logger.warn(`Feed failed: ${feed}`, e); }
  }
  const unique = [...new Map(all.map(x => [x.title, x])).values()].slice(0, 100);
  if (unique.length < 20) throw new Error('Not enough current-affairs headlines fetched');

  const now = Date.now();
  const today = new Date(now).toLocaleDateString('mr-IN', { timeZone: 'Asia/Kolkata', day: '2-digit', month: '2-digit', year: 'numeric' });
  const batch = db.batch();

  // 25 live questions, each built from four fresh headlines. The correct answer is
  // always one of today's verified headlines; the remaining three are distractors.
  for (let i = 0; i < 25; i++) {
    const base = i * 4;
    const choices = [unique[base % unique.length], unique[(base + 1) % unique.length], unique[(base + 2) % unique.length], unique[(base + 3) % unique.length]];
    const correct = i % 4;
    const ref = db.collection('current_affairs').doc(`live-${i + 1}`);
    batch.set(ref, {
      category: 'चालू घडामोडी', chapter: 'Live • Auto Update',
      question: `आजच्या (${today}) ताज्या घडामोडींमध्ये खालीलपैकी कोणती बातमी नोंदली आहे?`,
      options: choices.map(x => x.title), answer: correct, difficulty: i < 9 ? 'Easy' : i < 18 ? 'Medium' : 'Hard',
      source: 'Google News RSS headlines', sourceUrl: choices[correct].link,
      published: true, updatedAt: now, newsDate: choices[correct].pubDate || today
    }, { merge: true });
  }
  await batch.commit();
  logger.info(`Current affairs updated: ${Math.min(unique.length, 100)} headlines → 25 quiz questions`);
});

// V17: Secure quiz submission. The Android client sends only question IDs and
// selected option indexes. The server reads the authoritative answer from Firestore,
// calculates the score and writes the score/coin transaction atomically.
const { onCall, HttpsError } = require('firebase-functions/v2/https');

exports.submitQuiz = onCall({ region: 'asia-south1', enforceAppCheck: false }, async (request) => {
  if (!request.auth) throw new HttpsError('unauthenticated', 'Login required');
  const data = request.data || {};
  const refs = Array.isArray(data.questionRefs) ? data.questionRefs.slice(0, 50) : [];
  const answers = Array.isArray(data.answers) ? data.answers.slice(0, 50) : [];
  if (!refs.length || refs.length !== answers.length) throw new HttpsError('invalid-argument', 'Invalid quiz payload');

  const docs = [];
  for (const ref of refs) {
    if (!ref || !['questions', 'current_affairs'].includes(ref.collection) || !ref.id) {
      throw new HttpsError('invalid-argument', 'Invalid question reference');
    }
    const snap = await db.collection(ref.collection).doc(String(ref.id)).get();
    if (!snap.exists || snap.data().published !== true) {
      throw new HttpsError('failed-precondition', 'Question is not available');
    }
    docs.push(snap.data());
  }

  let score = 0;
  let coinsAwarded = 0;
  const maxCoins = 250;
  docs.forEach((q, i) => {
    const selected = Number(answers[i]);
    if (Number.isInteger(selected) && selected === Number(q.answer)) {
      score++;
      const d = String(q.difficulty || 'Easy').toLowerCase();
      coinsAwarded += d === 'hard' ? 20 : d === 'medium' ? 10 : 5;
    }
  });
  if (score === docs.length) coinsAwarded += 50;
  if (data.quizMode === 'daily') coinsAwarded += 25;
  coinsAwarded = Math.min(coinsAwarded, maxCoins);

  const uid = request.auth.uid;
  const userRef = db.collection('users').doc(uid);
  const scoreRef = db.collection('scores').doc();
  const attemptRef = db.collection('quiz_attempts').doc();
  const txRef = db.collection('coin_transactions').doc();
  const now = Date.now();

  const result = await db.runTransaction(async tx => {
    const userSnap = await tx.get(userRef);
    const old = userSnap.exists ? userSnap.data() : {};
    const oldCoins = Number(old.coins || 0);
    const newCoins = oldCoins + coinsAwarded;
    tx.set(userRef, {
      name: String(data.name || old.name || 'खेळाडू').slice(0, 40),
      coins: newCoins,
      totalCorrect: Number(old.totalCorrect || 0) + score,
      quizzesPlayed: Number(old.quizzesPlayed || 0) + 1,
      updatedAt: now
    }, { merge: true });
    tx.set(scoreRef, {
      uid,
      name: String(data.name || old.name || 'खेळाडू').slice(0, 40),
      score,
      total: docs.length,
      className: String(data.className || ''),
      subject: String(data.subject || ''),
      chapter: String(data.chapter || ''),
      quizMode: String(data.quizMode || 'chapter'),
      createdAt: now
    });
    tx.set(attemptRef, {
      uid,
      score,
      total: docs.length,
      quizMode: String(data.quizMode || 'chapter'),
      questionCount: docs.length,
      createdAt: now
    });
    if (coinsAwarded > 0) tx.set(txRef, {
      uid,
      type: 'quiz_reward',
      amount: coinsAwarded,
      quizAttemptId: attemptRef.id,
      createdAt: now
    });
    return { totalCoins: newCoins };
  });

  return { score, total: docs.length, coinsAwarded, totalCoins: result.totalCoins };
});
