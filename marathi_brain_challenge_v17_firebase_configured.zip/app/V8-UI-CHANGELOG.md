# Marathi Brain Challenge V8 – UI Update

- Home screen redesigned for clear readability and low-glare daily use.
- Reduced saturated purple/yellow usage; uses calm navy, slate, white and muted gold accents.
- Menu labels now match the app identity: वर्गनिहाय प्रश्नमंजुषा, ज्ञानविषय, आजची प्रश्नमंजुषा, माझा स्कोअर, बक्षिसे, माझे प्रोफाइल, Coins मिळवा, अॅपविषयी.
- Added detailed About App section with purpose, features, content notes, current-affairs note and data-storage explanation.
- Updated About version to 8.0.0 for this UI release.
- Existing quiz, coins, streak, rewards, profile, score, Firebase and admin functionality is preserved.
