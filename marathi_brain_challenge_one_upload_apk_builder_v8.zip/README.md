# Marathi Brain Challenge – V8 UI Builder

## काय बदलले?
V8 मध्ये V7 ची सर्व features कायम ठेवून Home Screen आणि menu चे visual design अधिक स्वच्छ, शांत आणि वाचायला सोपे केले आहे. Saturated purple/yellow कमी करून calm navy/slate/white + muted gold accents वापरले आहेत.

### Home Menu
- वर्गनिहाय प्रश्नमंजुषा
- ज्ञानविषय
- आजची प्रश्नमंजुषा
- माझा स्कोअर
- बक्षिसे
- माझे प्रोफाइल
- Coins मिळवा
- अॅपविषयी

### About App
अॅपचे उद्दिष्ट, विषय, Quiz Levels, Coins/Rewards, Current Affairs, data storage आणि content verification note यांची माहिती जोडली आहे.

## Build
या wrapper मध्ये `v2-project.zip` आहे. GitHub Actions workflow ने त्यातून player/admin/firebase project extract करून Capacitor Android APK build करायचा आहे.

**महत्त्वाचे:** GitHub repository मध्ये workflow file स्वतंत्रपणे `.github/workflows/build-apk.yml` म्हणून ठेवावी. ZIP upload केल्याने GitHub workflow आपोआप सक्रिय होत नाही.
