# Marathi Brain Challenge V17

V16 source project upgraded for V17. The project is designed for GitHub-based APK builds, so a PC is not required.

## V17 changes
- Secure `submitQuiz` Cloud Function calculates scores from Firestore answers.
- Coins and score rewards for Firebase-backed quizzes are server-side.
- Client no longer grants a Rewarded Ad reward when the native AdMob bridge is unavailable.
- Firestore rules prevent players from creating/updating scores, profiles, quiz attempts and coin transactions directly.
- Admin Web App upgraded with Question CRUD, Current Affairs CRUD, filters, CSV import/export, user summary and reward policy.
- Question fields now support explanation, hint and source.

## Firebase setup
1. Put the Firebase Web App config in `player/firebase-config.js` and `admin/firebase-config.js`.
2. Enable Anonymous Authentication for the Player app (or later add Google/Email login).
3. Enable Email/Password Authentication for Admin.
4. Create `admins/<ADMIN_UID>` with `{ "role": "admin" }`.
5. Deploy rules and functions:
   `firebase deploy --only firestore:rules,functions`

### Important
The local starter question bank is still included for offline/demo operation. For production learning content, publish verified questions through the Admin Web App.

## Admin
Open the `admin/` folder from a static host (Firebase Hosting, GitHub Pages, etc.) after adding the Firebase config.

## Android build
Use `BUILD-WORKFLOW-V17.yml` from GitHub Actions. The workflow keeps the existing Capacitor build approach and produces a Debug APK artifact. Replace test AdMob IDs before production release.

## Firebase Backend Deployment Without a PC (V17)

This project includes `DEPLOY-FIREBASE-V17.yml`. It deploys the V17 Cloud Function (`submitQuiz`) and Firestore rules through GitHub Actions, so a PC is not required.

### One-time GitHub setup

1. Open your Firebase project in Firebase Console.
2. Go to **Project settings → Service accounts** and generate a new private key JSON. Keep this file private.
3. In GitHub open **Repository → Settings → Secrets and variables → Actions → New repository secret**.
4. Add:
   - `FIREBASE_PROJECT_ID` = your Firebase Project ID (not the display name).
   - `FIREBASE_SERVICE_ACCOUNT_JSON` = the complete contents of the downloaded service-account JSON file.
5. Make sure `marathi_brain_challenge_fixed_v17.zip` is in the repository root.
6. Put `DEPLOY-FIREBASE-V17.yml` under `.github/workflows/`.
7. Open **Actions → Deploy Firebase Backend V17 → Run workflow**.

The workflow extracts the V17 project, installs the Firebase CLI and Cloud Functions dependencies, then deploys **Firestore Rules + Cloud Functions**. The service-account JSON is written only inside the temporary GitHub runner and deleted at the end.

### Important

Do **not** paste the service-account JSON into chat, README, source code, or a normal repository file. GitHub Actions Secrets should hold it.

The workflow does not deploy the player/admin Firebase Web App configuration. `player/firebase-config.js` and `admin/firebase-config.js` still need the real Firebase Web App config values in the source package before the APK/admin app can connect to your Firebase project.
