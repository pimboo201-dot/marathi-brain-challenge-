# Firebase setup — V6

## 1) Firestore collections
- `questions` — class-wise questions
- `current_affairs` — automatically refreshed live current-affairs quiz
- `admins` — admin UIDs
- `scores` — leaderboard scores

## 2) Current Affairs — automatic update
V6 includes `functions/` with a Firebase Cloud Function named `updateCurrentAffairs`.
It runs every 6 hours (Asia/Kolkata), reads fresh Google News RSS headlines, and writes **25 live quiz questions** into `current_affairs`.

### Deploy
From the `firebase` folder after installing Firebase CLI:
1. `firebase login`
2. `firebase use marathi-brain-challenge`
3. `cd functions`
4. `npm install`
5. `cd ..`
6. `firebase deploy --only functions:updateCurrentAffairs,firestore:rules`

Scheduled Cloud Functions require a Firebase/Google Cloud project with the required billing plan enabled. RSS access is used here so there is no news API key to put inside the app.

### Important limitation
The automatic feed creates headline-based current-affairs questions. For high-quality exam-style factual MCQs (e.g. “कोण नियुक्त झाले?”, “कोणत्या योजनेचा निर्णय झाला?”), add a trusted editorial/teacher review layer or a server-side LLM question-generation step before publishing. Do not put private API keys in the Android app.

## 3) Admin security
Enable Firebase Authentication → Email/Password. Create an admin user and create `admins/<UID>` with `{role:"admin"}`. The Player app has no Admin link.

## 4) Player Firebase config
Copy the Firebase Web App config into both `player/firebase-config.js` and `admin/firebase-config.js`. Never put service-account/private keys in the app.

## 5) Firestore rules
Deploy `firestore.rules`. Public users can read only published questions/current-affairs; only authenticated admin UIDs can write them.

## 6) Ads
V6 still has a TEST ad UI. Production Android monetization should use the official Google Mobile Ads SDK/AdMob with test IDs during development. Do not trust client-side coin rewards for cash redemption.
