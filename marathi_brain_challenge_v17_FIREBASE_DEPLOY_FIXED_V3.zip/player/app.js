import { firebaseConfig } from './firebase-config.js';
import { buildGeneralCategoryQuestions } from './category-bank.js';
import { initializeApp } from 'https://www.gstatic.com/firebasejs/12.1.0/firebase-app.js';
import { getAuth, signInAnonymously } from 'https://www.gstatic.com/firebasejs/12.1.0/firebase-auth.js';
import { getFirestore, collection, getDocs, query, where, orderBy, limit } from 'https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js';
import { getFunctions, httpsCallable } from 'https://www.gstatic.com/firebasejs/12.1.0/firebase-functions.js';

/* Original, copyright-free starter question bank.
   12 classes × 6 subjects × 5 chapters × 5 questions = 1,800 local questions.
   Questions are intentionally generated from small educational templates so the
   app can be tested immediately; Firebase can replace them with your verified bank. */
const subjects=['मराठी','हिंदी','इंग्रजी','गणित','विज्ञान','सामाजिक शास्त्रे'];
const chapterMap={
 'मराठी':['वर्णमाला व शब्द','नाम व सर्वनाम','क्रियापद व काळ','समानार्थी व विरुद्धार्थी','वाचन व लेखन'],
 'हिंदी':['वर्णमाला और शब्द','संज्ञा और सर्वनाम','क्रिया और काल','पर्यायवाची और विलोम','पठन और लेखन'],
 'इंग्रजी':['Alphabet & Words','Nouns & Pronouns','Verbs & Tenses','Vocabulary','Reading & Sentences'],
 'गणित':['संख्या व स्थानिक किंमत','बेरीज व वजाबाकी','गुणाकार व भागाकार','अपूर्णांक व दशांश','भूमिती व मोजमाप'],
 'विज्ञान':['सजीव व निर्जीव','पदार्थ व त्यांचे गुणधर्म','बल ऊर्जा व प्रकाश','पर्यावरण','आरोग्य व दैनंदिन विज्ञान'],
 'सामाजिक शास्त्रे':['कुटुंब व समाज','भारताचा भूगोल','इतिहासाची ओळख','नागरिकशास्त्र','अर्थव्यवस्था व जबाबदारी']
};
function q(category,chapter,question,options,answer,difficulty='Easy'){return {category,chapter,question,options,answer,difficulty,published:true}}
function mathQuestions(c,chapter){const base=c+2;const sets=[
 [`${c} आणि ${base} यांची बेरीज किती?`,[c+base,c+base+1,c+base-1,c+base+2],0],
 [`${base+5} मधून ${c} वजा केल्यास किती उरते?`,[base+5-c,base+5-c+1,base+5-c-1,c],0],
 [`${c+2} × 2 = ?`,[(c+2)*2,(c+2)*3,c+4,c+2],0],
 [`${c+8} ÷ 2 = ?`,[(c+8)/2,(c+8)/2+1,(c+8)/2-1,c],0],
 [`1/2 + 1/2 = ?`,['1','1/2','2','0'],0]
]; return sets.map((x,i)=>q(`इयत्ता ${c} • गणित`,chapter,`${x[0]}`,x[1].map(String),x[2],i<2?'Easy':i<4?'Medium':'Hard'))}
function marathiQuestions(c,chapter){const sets=[
 ['मराठी वर्णमालेतील स्वरांपैकी एक कोणता?',['अ','क','ट','प'],0],
 ['“मुलगा” या शब्दाचा स्त्रीलिंगी शब्द कोणता?',['मुलगी','मुलगे','मुलांचे','मुलगा'],0],
 ['“सुंदर” या शब्दाचा विरुद्धार्थी शब्द कोणता?',['कुरूप','मोठा','लहान','जलद'],0],
 ['“तो खेळतो.” या वाक्यात क्रियापद कोणते?',['तो','खेळतो','वाक्यात','या'],1],
 ['“घर” या शब्दाचे अनेकवचन कोणते?',['घरे','घरा','घरांनी','घरी'],0]
]; return sets.map((x,i)=>q(`इयत्ता ${c} • मराठी`,chapter,x[0],x[1],x[2],i<2?'Easy':i<4?'Medium':'Hard'))}
function hindiQuestions(c,chapter){const sets=[
 ['हिंदी वर्णमाला में स्वर का उदाहरण कौन-सा है?',['अ','क','ट','प'],0],
 ['“लड़का” का स्त्रीलिंग शब्द कौन-सा है?',['लड़की','लड़के','लड़कों','लड़का'],0],
 ['“सुंदर” का विलोम शब्द कौन-सा है?',['कुरूप','बड़ा','छोटा','तेज'],0],
 ['“राम खेलता है।” वाक्य में क्रिया कौन-सी है?',['राम','खेलता है','वाक्य','है'],1],
 ['“घर” का बहुवचन क्या है?',['घर','घरों','घरी','घरें'],1]
 ]; return sets.map((x,i)=>q(`इयत्ता ${c} • हिंदी`,chapter,x[0],x[1],x[2],i<2?'Easy':i<4?'Medium':'Hard'))}
function englishQuestions(c,chapter){const sets=[
 ['Which is a vowel?',['A','B','C','D'],0],
 ['Choose the plural of “book”.',['books','bookes','book','booking'],0],
 ['Choose the correct pronoun: “___ am happy.”',['I','He','They','She'],0],
 ['Choose the past form of “go”.',['went','goed','goes','going'],0],
 ['Choose the opposite of “big”.',['small','tall','long','fast'],0]
]; return sets.map((x,i)=>q(`इयत्ता ${c} • इंग्रजी`,chapter,x[0],x[1],x[2],i<2?'Easy':i<4?'Medium':'Hard'))}
function scienceQuestions(c,chapter){const sets=[
 ['वनस्पतींना वाढण्यासाठी यापैकी कशाची गरज असते?',['पाणी','प्लास्टिक','दगड','काच'],0],
 ['पाण्याचे रासायनिक सूत्र कोणते?',['H2O','CO2','O2','NaCl'],0],
 ['प्रकाशाचा मुख्य नैसर्गिक स्रोत कोणता?',['सूर्य','चंद्र','ढग','माती'],0],
 ['पर्यावरणातील झाडांचे महत्त्व काय?',['ऑक्सिजन व निवारा','फक्त आवाज','फक्त उष्णता','फक्त धूर'],0],
 ['मानवी शरीरात रक्त पंप करणारा अवयव कोणता?',['हृदय','फुफ्फुसे','त्वचा','हाड'],0]
]; return sets.map((x,i)=>q(`इयत्ता ${c} • विज्ञान`,chapter,x[0],x[1],x[2],i<2?'Easy':i<4?'Medium':'Hard'))}
function socialQuestions(c,chapter){const sets=[
 ['भारताची राजधानी कोणती?',['नवी दिल्ली','मुंबई','पुणे','नागपूर'],0],
 ['भारताच्या नकाशावर उत्तरेकडे कोणता पर्वतरांग समूह आहे?',['हिमालय','सह्याद्री','अरावली','नीलगिरी'],0],
 ['इतिहासाचा अभ्यास कशासाठी उपयुक्त आहे?',['भूतकाळ समजण्यासाठी','फक्त खेळासाठी','फक्त गणितासाठी','फक्त चित्रकलेसाठी'],0],
 ['चांगल्या नागरिकाची एक जबाबदारी कोणती?',['नियमांचे पालन','कचरा रस्त्यावर टाकणे','पाणी वाया घालवणे','वाहतुकीचे नियम तोडणे'],0],
 ['पैशाची बचत करण्याचा चांगला मार्ग कोणता?',['गरजेनुसार खर्च व बचत','सर्व पैसे लगेच खर्च करणे','कर्ज वाढवणे','हिशोब न ठेवणे'],0]
]; return sets.map((x,i)=>q(`इयत्ता ${c} • सामाजिक शास्त्रे`,chapter,x[0],x[1],x[2],i<2?'Easy':i<4?'Medium':'Hard'))}
function buildBank(){const out=[];for(let c=1;c<=12;c++){for(const s of subjects){for(const ch of chapterMap[s]){const fn=s==='मराठी'?marathiQuestions:s==='हिंदी'?hindiQuestions:s==='इंग्रजी'?englishQuestions:s==='गणित'?mathQuestions:s==='विज्ञान'?scienceQuestions:socialQuestions;out.push(...fn(c,ch));}}}return out}
const demo=buildBank();
const generalCategoryQuestions=buildGeneralCategoryQuestions();
let questions=[...demo,...generalCategoryQuestions],game=[],idx=0,correct=0,answered=false,coins=Number(localStorage.getItem('coins')||0),selectedClass='',selectedSubject='',selectedChapter='',selectedDifficulty='',quizMode='chapter',coinsEarned=0,streak=0,hintUsed=false,answers=[],serverQuiz=false;
let firebaseDb=null, firebaseUser=null, firebaseFunctions=null, submitQuizFn=null;
let totalCorrect=Number(localStorage.getItem('totalCorrect')||0),quizzesPlayed=Number(localStorage.getItem('quizzesPlayed')||0),bestStreak=Number(localStorage.getItem('bestStreak')||0),lastDaily=localStorage.getItem('lastDaily')||'',userName=localStorage.getItem('userName')||'';
const LEVEL_UNLOCK={Easy:0,Medium:20,Hard:100};
// V17: server-backed rewards are enabled only when Firebase is configured.
const V17_VERSION='17.0.0';
const $=id=>document.getElementById(id); $('coins').textContent=coins;

async function loadOnline(){try{if(!firebaseConfig.projectId||firebaseConfig.projectId==='YOUR_PROJECT_ID'){renderClasses();renderCategories();return}const app=initializeApp(firebaseConfig);firebaseDb=getFirestore(app);firebaseFunctions=getFunctions(app,'asia-south1');submitQuizFn=httpsCallable(firebaseFunctions,'submitQuiz');const auth=getAuth(app);try{const cred=await signInAnonymously(auth);firebaseUser=cred.user}catch(e){console.log('Anonymous auth unavailable',e)}const snap=await getDocs(query(collection(firebaseDb,'questions'),where('published','==',true)));const online=snap.docs.map(d=>({id:d.id,...d.data()}));if(online.length)questions=[...demo,...generalCategoryQuestions,...online];renderClasses();renderCategories();await loadCurrentAffairs()}catch(e){console.log('Offline/demo mode',e);renderClasses();renderCategories();loadCurrentAffairs()}}
loadOnline();

const screenHistory=[];
let nativeAppPlugin=null,nativeAdMob=null;
const ADMOB_TEST_REWARDED='ca-app-pub-3940256099942544/5224354917';
function nativePlugin(name){try{return window.Capacitor?.Plugins?.[name]||null}catch(e){return null}}
async function initNativeShell(){
  try{
    nativeAppPlugin=nativePlugin('App');
    if(nativeAppPlugin?.addListener){
      await nativeAppPlugin.addListener('backButton',async()=>{
        if(screenHistory.length){goBack();return}
        const current=document.querySelector('.screen.active')?.id;
        if(current&&current!=='homeScreen'){goHome();return}
        try{await nativeAppPlugin.minimizeApp()}catch(e){showToast('मुख्य पानावर आहात. App बंद न करता Home वर ठेवले.')} 
      });
    }
  }catch(e){console.log('Native App plugin unavailable',e)}
  try{
    nativeAdMob=nativePlugin('AdMob');
    if(nativeAdMob?.initialize){await nativeAdMob.initialize({maxAdContentRating:'General'});}
  }catch(e){console.log('AdMob initialization unavailable',e)}
}
window.goHome=()=>{screenHistory.length=0;show('homeScreen',false);};
window.goBack=()=>{
  if(screenHistory.length){const target=screenHistory.pop();show(target,false);return;}
  const current=document.querySelector('.screen.active')?.id;
  if(current!=='homeScreen'){show('homeScreen',false);return;}
  if(nativeAppPlugin?.minimizeApp) nativeAppPlugin.minimizeApp().catch(()=>showToast('मुख्य पानावर आहात.'));
  else showToast('मुख्य पानावर आहात.');
};
window.showAbout=()=>show('infoScreen');
window.showProfile=()=>{ $('profileName').value=userName; $('profileMsg').textContent=''; show('profileScreen') };
window.saveProfile=()=>{const n=$('profileName').value.trim();if(!n){$('profileMsg').textContent='कृपया नाव टाका.';return}userName=n;localStorage.setItem('userName',n);$('profileMsg').textContent='✅ नाव सेव्ह झाले.';renderHomeGreeting()};
window.showScores=async()=>{const rows=JSON.parse(localStorage.getItem('scoreHistory')||'[]');let top=rows.sort((a,b)=>b.score-a.score).slice(0,5);if(firebaseDb){try{const snap=await getDocs(query(collection(firebaseDb,'scores'),orderBy('score','desc'),limit(10)));if(!snap.empty)top=snap.docs.map(d=>d.data())}catch(e){console.log('Leaderboard offline',e)}}$('scoreSummary').innerHTML=`<div class="stat-grid"><div><b>${totalCorrect}</b><small>योग्य उत्तरे</small></div><div><b>${quizzesPlayed}</b><small>Quiz खेळले</small></div><div><b>${bestStreak}</b><small>Best Streak</small></div></div><h3>🏆 Local Leaderboard</h3>${top.length?top.map((x,i)=>`<div class="leader-row"><span>#${i+1}</span><b>${esc(x.name||'खेळाडू')}</b><strong>${x.score}</strong></div>`).join(''):'<p class="muted">अजून Score History नाही.</p>'}<p class="muted tiny">Leaderboard सध्या या device वर local आहे. Firebase मध्ये account-based leaderboard जोडण्यासाठी Firebase Auth आवश्यक आहे.</p>`;show('scoresScreen')};
window.showRewards=()=>{renderRewards();show('rewardsScreen')};
window.showAds=()=>show('adsScreen');
window.openClasses=()=>{renderClasses();show('classScreen')};
window.openCategories=()=>{renderCategories();show('categoryScreen');loadCurrentAffairs()};
function renderHomeGreeting(){ $('hello').textContent=userName?`नमस्कार, ${userName}! 👋`:'नमस्कार! 👋'; }
renderHomeGreeting();
function renderClasses(){const list=$('classList');list.innerHTML=Array.from({length:12},(_,i)=>`<button onclick="selectClass(${i+1})"><span class="class-badge">${i+1}</span><div><b>इयत्ता ${i+1} वी</b><small>विषय आणि अध्याय निवडा</small></div><strong>›</strong></button>`).join('')}
function renderCategories(){const counts={};generalCategoryQuestions.forEach(q=>counts[q.category]=(counts[q.category]||0)+1);const names=Object.keys(counts);$('categoryList').innerHTML=names.map(c=>`<button onclick="startGeneralCategory('${encodeURIComponent(c)}')"><span class="subject-icon">${categoryIcon(c)}</span><div><b>${esc(c)}</b><small>${counts[c]} प्रश्न • Easy / Medium / Hard</small></div><strong>›</strong></button>`).join('');renderCurrentAffairsList(currentAffairsCache)}
let currentAffairsCache=[];
function categoryIcon(c){if(c.includes('महाराष्ट्र'))return '🏰';if(c.includes('भारत'))return '🇮🇳';if(c.includes('इतिहास'))return '📜';if(c.includes('भूगोल'))return '🌍';if(c.includes('विज्ञान'))return '🔬';if(c.includes('मराठी'))return '📖';if(c.includes('तर्क'))return '🧩';if(c.includes('क्रीडा'))return '🏅';return '🧠'}
window.startGeneralCategory=(encoded)=>{const cat=decodeURIComponent(encoded);selectedClass='General';selectedSubject=cat;selectedChapter='सामान्य प्रश्न';selectedDifficulty='Mixed';quizMode='general';const pool=generalCategoryQuestions.filter(q=>q.category===cat);startGame(pool,Math.min(pool.length,5))};
async function loadCurrentAffairs(){if(!firebaseDb){renderCurrentAffairsList([]);$('currentStatus').textContent='Firebase जोडल्यावर Live अपडेट्स सुरू होतील.';return}try{const snap=await getDocs(query(collection(firebaseDb,'current_affairs'),where('published','==',true),limit(50)));currentAffairsCache=snap.docs.map(d=>({id:d.id,...d.data()})).sort((a,b)=>(b.updatedAt||0)-(a.updatedAt||0)).slice(0,25);renderCurrentAffairsList(currentAffairsCache);$('currentStatus').textContent=currentAffairsCache.length?`${currentAffairsCache.length} Live प्रश्न • शेवटचे अपडेट: ${new Date().toLocaleTimeString('mr-IN',{hour:'2-digit',minute:'2-digit'})}`:'अजून Live प्रश्न उपलब्ध नाहीत.'}catch(e){console.log('Current affairs load failed',e);$('currentStatus').textContent='Live feed उपलब्ध नाही. Firebase/auto-update setup तपासा.';renderCurrentAffairsList([])}}
window.refreshCurrentAffairs=async()=>{await loadCurrentAffairs();showToast('🔄 चालू घडामोडी Refresh केल्या.')};
function renderCurrentAffairsList(arr){const box=$('currentAffairsList');if(!arr||!arr.length){box.innerHTML='<div class="empty-card">📰 Live चालू घडामोडी प्रश्न Firebase auto-update झाल्यावर येथे दिसतील.</div>';return}box.innerHTML=arr.slice(0,25).map((x,i)=>`<button onclick="startCurrentAffair(${i})"><span class="class-badge">${i+1}</span><div><b>${esc(x.question)}</b><small>${esc(x.dateLabel||'आज') } • ${difficultyLabel(x.difficulty)}</small></div><strong>›</strong></button>`).join('')}
window.startCurrentAffair=(i)=>{selectedClass='Current';selectedSubject='चालू घडामोडी';selectedChapter='Live';selectedDifficulty='Mixed';quizMode='current';const pool=currentAffairsCache.slice();const first=currentAffairsCache[i];if(first){pool.sort(()=>Math.random()-.5);startGame(pool,Math.min(pool.length,5))}}

window.selectClass=(c)=>{selectedClass=String(c);renderSubjects();show('subjectScreen')};
function renderSubjects(){const arr=subjects; $('subjectList').innerHTML=arr.map(s=>`<button onclick="selectSubject('${encodeURIComponent(s)}')"><span class="subject-icon">${iconFor(s)}</span><div><b>${s}</b><small>5 अध्याय • 25 प्रश्न</small></div><strong>›</strong></button>`).join('');$('subjectTitle').textContent=`इयत्ता ${selectedClass} वी • विषय`}
window.selectSubject=(encoded)=>{selectedSubject=decodeURIComponent(encoded);renderChapters();show('chapterScreen')};
function renderChapters(){const arr=chapterMap[selectedSubject]||[];$('chapterList').innerHTML=arr.map((c,i)=>`<button onclick="selectChapter(${i})"><span class="chapter-num">${i+1}</span><div><b>${esc(c)}</b><small>5 प्रश्न • 25 मध्ये ${i+1} वा अध्याय</small></div><strong>›</strong></button>`).join('');$('chapterTitle').textContent=`${selectedSubject} • अध्याय`}
window.selectChapter=(i)=>{selectedChapter=(chapterMap[selectedSubject]||[])[i];$('selectedChapterTitle').textContent=selectedChapter;show('levelScreen')};
window.startCategoryLevel=(level)=>{selectedDifficulty=level;quizMode='chapter';const need=LEVEL_UNLOCK[level];if(totalCorrect<need){alert(`${level} Level Unlock करण्यासाठी आणखी ${need-totalCorrect} योग्य उत्तरे द्या.`);return}const pool=questions.filter(q=>q.category===`इयत्ता ${selectedClass} • ${selectedSubject}`&&q.chapter===selectedChapter&&normalizeDifficulty(q.difficulty)===level);startGame(pool,Math.min(pool.length,5))};
window.startDaily=()=>{quizMode='daily';selectedClass='Daily';selectedSubject='Mixed';selectedChapter='Daily Quiz';selectedDifficulty='Mixed';const pool=[...questions].sort(()=>Math.random()-.5);startGame(pool,Math.min(pool.length,5))};
function startGame(pool,n){if(!pool.length){alert(`या अध्यायात ${selectedDifficulty} Level चे प्रश्न उपलब्ध नाहीत.`);return}game=[...pool].sort(()=>Math.random()-.5).slice(0,n);idx=0;correct=0;coinsEarned=0;streak=0;answers=[];serverQuiz=!!(firebaseDb&&firebaseUser&&submitQuizFn&&game.length&&game.every(gq=>gq.id));show('quizScreen');render()}
function show(id,record=true){
  const current=document.querySelector('.screen.active')?.id;
  if(current===id)return;
  if(record&&current)screenHistory.push(current);
  document.querySelectorAll('.screen').forEach(x=>x.classList.remove('active'));
  $(id).classList.add('active');
  scrollTo(0,0);
  syncNativeAdVisibility(id);
}
function render(){answered=false;hintUsed=false;const q=game[idx];$('counter').textContent=`प्रश्न ${idx+1}/${game.length}`;$('score').textContent=`बरोबर: ${correct} • 🪙 +${coinsEarned}`;$('bar').style.width=((idx)/game.length*100)+'%';$('cat').textContent=`${q.category} • ${q.chapter||''} • ${difficultyLabel(q.difficulty)}`;$('question').textContent=q.question;$('answers').innerHTML='';q.options.forEach((a,i)=>{let b=document.createElement('button');b.className='answer';b.textContent=`${'ABCD'[i]}) ${a}`;b.onclick=()=>{beep(520,45);answer(i,b)};$('answers').appendChild(b)});$('next').classList.add('hidden');$('hint').disabled=coins<30;$('hint').textContent='💡 Hint — 30 Coins'}
let audioCtx=null;function beep(freq,duration=100){try{audioCtx=audioCtx||new (window.AudioContext||window.webkitAudioContext)();if(audioCtx.state==='suspended')audioCtx.resume();const o=audioCtx.createOscillator(),g=audioCtx.createGain();o.type='sine';o.frequency.value=freq;o.connect(g);g.connect(audioCtx.destination);g.gain.setValueAtTime(.035,audioCtx.currentTime);g.gain.exponentialRampToValueAtTime(.001,audioCtx.currentTime+duration/1000);o.start();o.stop(audioCtx.currentTime+duration/1000)}catch(e){}}
function happySound(){beep(660,90);setTimeout(()=>beep(880,130),90)}function wrongSound(){beep(220,160)} function buzz(pattern){try{if(navigator.vibrate)navigator.vibrate(pattern)}catch(e){}}
function answer(i,b){if(answered)return;answered=true;answers[idx]=i;const q=game[idx];document.querySelectorAll('.answer').forEach((x,j)=>{if(j===q.answer)x.classList.add('correct')});if(i===q.answer){b.classList.add('correct');happySound();buzz([35,45,35]);correct++;streak++;totalCorrect++;bestStreak=Math.max(bestStreak,streak);localStorage.setItem('totalCorrect',totalCorrect);localStorage.setItem('bestStreak',bestStreak);if(!serverQuiz){const reward=coinValue(q.difficulty);coins+=reward;coinsEarned+=reward;if(streak===3){coins+=10;coinsEarned+=10;saveCoins();}}showToast('🎉 बरोबर उत्तर! छान!');}else{b.classList.add('wrong');wrongSound();buzz(90);streak=0;showToast(`❌ चुकीचे उत्तर. योग्य उत्तर: ${q.options[q.answer]}`)}if(!serverQuiz)saveCoins();$('score').textContent=`बरोबर: ${correct} • ${serverQuiz?'🪙 Reward शेवटी मिळेल':'🪙 +'+coinsEarned}`;$('next').classList.remove('hidden');$('hint').disabled=true}
$('hint').onclick=()=>{if(answered||hintUsed||coins<30)return;const q=game[idx];const wrong=[...document.querySelectorAll('.answer')].filter((_,i)=>i!==q.answer);wrong.sort(()=>Math.random()-.5).slice(0,2).forEach(b=>{b.disabled=true;b.style.opacity='.35'});coins-=30;saveCoins();hintUsed=true;beep(420,100);buzz(30);$('hint').textContent='💡 Hint वापरला';$('hint').disabled=true}
$('next').onclick=()=>{if(idx<game.length-1){idx++;render()}else finish()};
async function finish(){beep(880,180);buzz([30,40,60]);let bonus=0;if(quizMode==='daily'){bonus+=25;updateDailyStreak()}if(correct===game.length)bonus+=50;
  if(serverQuiz){
    try{
      const refs=game.map(q=>({collection:q.category==='चालू घडामोडी'||quizMode==='current'?'current_affairs':'questions',id:q.id}));
      const result=await submitQuizFn({questionRefs:refs,answers,quizMode,className:selectedClass,subject:selectedSubject,chapter:selectedChapter,name:userName||'खेळाडू'});
      const data=result.data||{}; coins=Number(data.totalCoins||coins); coinsEarned=Number(data.coinsAwarded||0); correct=Number(data.score||correct); saveCoins();
      showToast('☁️ Score आणि Coins सुरक्षितपणे sync झाले.');
    }catch(e){console.log('Secure quiz sync failed',e);showToast('⚠️ Cloud sync झाला नाही; Quiz result device वर जतन केला.');}
  }else{
    if(bonus){coins+=bonus;coinsEarned+=bonus}
  }
  quizzesPlayed++;localStorage.setItem('quizzesPlayed',quizzesPlayed);
  const history=JSON.parse(localStorage.getItem('scoreHistory')||'[]');history.push({name:userName||'खेळाडू',score:correct,date:new Date().toLocaleDateString('mr-IN')});localStorage.setItem('scoreHistory',JSON.stringify(history.slice(-50)));
  // Note: local/offline quizzes are not written to the 'scores' collection — Firestore
  // rules only allow the submitQuiz Cloud Function (serverQuiz path above) to write scores.
  saveCoins();show('resultScreen');$('final').textContent=`${correct} / ${game.length}`;$('message').textContent=correct===game.length?'अप्रतिम! 🔥 सर्व प्रश्न बरोबर!':correct>=game.length*.7?'खूप छान! 👏':'पुन्हा खेळा आणि स्कोअर वाढवा. 💪';$('rewardResult').innerHTML=`🪙 या Quiz मधून मिळाले <b>+${coinsEarned} Coins</b>${quizMode==='daily'?'<br>📅 Daily Streak अपडेट झाला.':''}${quizMode==='current'?'<br>📰 Live Current Affairs Quiz':' '}`}
function updateDailyStreak(){const today=localDateKey();if(lastDaily===today)return;const yesterday=localDateKey(-1);const ds=Number(localStorage.getItem('dailyStreak')||0);streak=lastDaily===yesterday?ds+1:1;localStorage.setItem('dailyStreak',streak);localStorage.setItem('lastDaily',today);lastDaily=today}
function localDateKey(offset=0){const d=new Date();d.setDate(d.getDate()+offset);return [d.getFullYear(),String(d.getMonth()+1).padStart(2,'0'),String(d.getDate()).padStart(2,'0')].join('-')}
function updateLiveDateTime(){const d=new Date();$('liveClock').textContent=d.toLocaleTimeString('mr-IN',{hour:'2-digit',minute:'2-digit',second:'2-digit'});$('liveDate').textContent=d.toLocaleDateString('mr-IN',{weekday:'long',year:'numeric',month:'long',day:'numeric'});$('streakHome').textContent=`🔥 ${Number(localStorage.getItem('dailyStreak')||0)} दिवस`;}
setInterval(updateLiveDateTime,1000);updateLiveDateTime();
function renderRewards(){const ds=Number(localStorage.getItem('dailyStreak')||0);const badgeData=[['🧠','Quiz Starter','10 योग्य उत्तरे',totalCorrect>=10],['🏅','Quiz Master','50 योग्य उत्तरे',totalCorrect>=50],['🔥','Streak Hero','5 सलग योग्य उत्तरे',bestStreak>=5],['🎯','Quiz Champion','10 Quizzes',quizzesPlayed>=10]];const badgeHtml=badgeData.map(b=>`<div class="badge-tile ${b[3]?'':'locked'}"><div class="badge-icon">${b[0]}</div><b>${b[1]}</b><small>${b[2]} • ${b[3]?'Unlocked':'Locked'}</small></div>`).join('');$('rewardCards').innerHTML=`<div class="reward-panel active" data-panel="overview"><div class="reward-overview-grid"><div class="reward-stat"><small>🪙 उपलब्ध Coins</small><b>${coins}</b></div><div class="reward-stat"><small>🔥 Daily Streak</small><b>${ds} दिवस</b></div><div class="reward-stat"><small>🏆 योग्य उत्तरे</small><b>${totalCorrect}</b></div><div class="reward-stat"><small>🎮 खेळलेले Quiz</small><b>${quizzesPlayed}</b></div></div><div class="reward-card highlight" style="margin-top:10px"><h3>🔥 Daily Streak</h3><p><b>${ds} दिवस</b> • आज: ${localDateKey()}</p><div class="live-line">🕒 <b>${$('liveClock').textContent}</b><span>${$('liveDate').textContent}</span></div><div class="progress-mini"><i style="width:${Math.min(ds/7*100,100)}%"></i></div></div><div class="reward-card"><h3>🔓 Level Progress</h3><p>Easy: Unlocked<br>Medium: ${totalCorrect>=20?'Unlocked':'20 योग्य उत्तरे आवश्यक'}<br>Hard: ${totalCorrect>=100?'Unlocked':'100 योग्य उत्तरे आवश्यक'}</p></div></div><div class="reward-panel" data-panel="badges"><div class="badge-grid">${badgeHtml}</div></div><div class="reward-panel" data-panel="redeem"><div class="reward-card"><h3>🎁 Redeem Rewards</h3><p class="muted">हे virtual in-app rewards आहेत; cash withdrawal नाही.</p><div class="redeem-grid"><button onclick="redeemReward(250,'🏅 Quiz Master Badge')">250 🪙<br><b>Quiz Master Badge</b></button><button onclick="redeemReward(500,'👑 Golden Crown')">500 🪙<br><b>Golden Crown</b></button><button onclick="redeemReward(1000,'✨ Premium Profile Frame')">1000 🪙<br><b>Premium Frame</b></button></div></div></div>`;switchRewardTab(window.__rewardTab||'overview')}
window.switchRewardTab=(tab)=>{window.__rewardTab=tab;document.querySelectorAll('.reward-tab').forEach(b=>b.classList.toggle('active',b.dataset.tab===tab));document.querySelectorAll('.reward-panel').forEach(p=>p.classList.toggle('active',p.dataset.panel===tab))}
window.redeemReward=(cost,label)=>{if(coins<cost){showToast(`🪙 ${cost} Coins आवश्यक आहेत.`);return}if(!confirm(`${label} साठी ${cost} Coins खर्च करायचे?`))return;coins-=cost;saveCoins();localStorage.setItem('lastRedeem',label);showToast(`🎁 ${label} Redeem झाले!`);renderRewards()};
function saveCoins(){localStorage.setItem('coins',coins);$('coins').textContent=coins}
function coinValue(d){d=normalizeDifficulty(d);return d==='Easy'?5:d==='Medium'?10:20}
function normalizeDifficulty(d){const x=String(d||'Easy').toLowerCase();if(x==='medium'||x==='midium')return'Medium';if(x==='hard')return'Hard';return'Easy'}
function difficultyLabel(d){const n=normalizeDifficulty(d);return n==='Easy'?'Easy 🟢':n==='Medium'?'Medium 🟡':'Hard 🔴'}
function iconFor(c){if(c.includes('इतिहास')||c.includes('सामाजिक'))return'🌏';if(c.includes('विज्ञान'))return'🔬';if(c.includes('भूगोल'))return'🌍';if(c.includes('मराठी'))return'📖';if(c.includes('गणित'))return'➗';if(c.includes('इंग्रजी'))return'🔤';return'🧠'}
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function showToast(t){const x=$('toast');x.textContent=t;x.classList.add('show');clearTimeout(window.__toast);window.__toast=setTimeout(()=>x.classList.remove('show'),1800)}
async function syncNativeAdVisibility(screenId){
  if(!nativeAdMob)return;
  try{if(nativeAdMob.hideBanner)await nativeAdMob.hideBanner();}catch(e){}
}
async function playRewardedAd(){
  if(!nativeAdMob?.prepareRewardVideoAd||!nativeAdMob?.showRewardVideoAd){
    showToast('📺 Rewarded Ad सध्या उपलब्ध नाही.');$('adRewardMsg').textContent='Ad bridge उपलब्ध नाही — Reward दिला जाणार नाही.';return;
  }
  $('adRewardBtn').disabled=true;$('adRewardMsg').textContent='⏳ Rewarded Ad तयार होत आहे…';
  try{
    try{
      const consent=await nativeAdMob.requestConsentInfo();
      if(consent?.isConsentFormAvailable&&consent?.status==='REQUIRED')await nativeAdMob.showConsentForm();
    }catch(e){console.log('Consent flow skipped',e)}
    await nativeAdMob.prepareRewardVideoAd({adId:ADMOB_TEST_REWARDED,isTesting:true});
    const reward=await nativeAdMob.showRewardVideoAd({adId:ADMOB_TEST_REWARDED});
    const amount=20;
    coins+=amount;saveCoins();
    $('adRewardMsg').textContent=`✅ Rewarded Ad पूर्ण • +${amount} Coins`;
    showToast(`🎁 Ad Reward मिळाला! +${amount} Coins`);
  }catch(e){
    console.log('Rewarded Ad failed',e);
    $('adRewardMsg').textContent='Ad सध्या उपलब्ध नाही. कृपया पुन्हा प्रयत्न करा.';
    showToast('⚠️ Ad load झाला नाही.');
  }finally{$('adRewardBtn').disabled=false;}
}
$('home').onclick=goHome;
$('adRewardBtn').onclick=playRewardedAd;
setTimeout(initNativeShell,250);
