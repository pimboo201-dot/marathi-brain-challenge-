// Firebase Web App config for Marathi Brain Challenge.
// This config is safe to ship in the web/Android client; Firebase Security Rules
// and Authentication control access to protected data.
export const firebaseConfig = {
  apiKey: "AIzaSyDAJ7QUjhLybxF9IGQqUK54inhNm31nVPA",
  authDomain: "marathi-brain-challenge.firebaseapp.com",
  projectId: "marathi-brain-challenge",
  storageBucket: "marathi-brain-challenge.firebasestorage.app",
  messagingSenderId: "867961313798",
  appId: "1:867961313798:web:2df9b34bb66e80a9f78187",
  measurementId: "G-CWML64144B"
};
