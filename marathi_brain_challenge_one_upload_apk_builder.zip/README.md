# मराठी बुद्धीचाचणी — V7

## V7 नवीन बदल
- Original, phone-first Home Screen.
- इयत्ता 1 ली ते 12 वी → विषय → अध्याय → Easy / Medium / Hard.
- स्वतंत्र **विशेष Categories** section; Class Quiz पासून वेगळा.
- 9 general categories × 25 original questions = **225 questions**:
  सामान्य ज्ञान, महाराष्ट्र विशेष, भारत विशेष, इतिहास, भूगोल, विज्ञान, मराठी भाषा, तर्कशक्ती, क्रीडा.
- General Categories मध्ये Easy / Medium / Hard rewards कायम आहेत.
- **चालू घडामोडी** स्वतंत्र Live section: Firebase `current_affairs` collection मधून 25 प्रश्न दाखवते.
- Firebase Cloud Function `updateCurrentAffairs` दर 6 तासांनी fresh RSS headlines घेऊन 25 live questions अपडेट करते.
- Live time/date + Daily Streak, Coins, Badges, Profile, Score/Leaderboard, Rewards, sound/vibration.
- Admin Player UI मध्ये दिसत नाही; Admin साठी Firebase Email/Password + `admins/<UID>` सुरक्षा तपासणी आहे.
- Admin मध्ये General Category questions तयार/संपादित करण्यासाठी Category field आहे.
- About मध्ये नवीन प्रश्न/माहितीचा उल्लेख नाही.

## Current Affairs auto-update
`firebase/functions/` deploy केल्यावर scheduled Cloud Function चालते. ती Google News RSS headlines वापरून headline-based current-affairs quiz तयार करते. ही व्यवस्था app मध्ये private API key ठेवत नाही.

**महत्त्वाचे:** ही live headline quiz आहे. परीक्षेसाठी अचूक factual MCQs हवेत तर संपादकीय/शिक्षक review किंवा server-side question-generation layer जोडणे योग्य आहे.

## Firebase
`firebase/README.md` मधील setup steps पूर्ण करा. `firestore.rules` deploy करा. Web config `player/firebase-config.js` आणि `admin/firebase-config.js` मध्ये भरा.

## Ads / Monetization
V7 मध्ये TEST ad UI आहे. Production Android app मध्ये official Google Mobile Ads SDK/AdMob native wrapper मध्ये जोडावा. Test IDs ने testing करा. Cash rewards साठी client-side coins/score वर विश्वास ठेवू नका; server-side validation आवश्यक आहे.


V7 update: Class 1-12 मध्ये हिंदी विषय जोडला आहे. Class → Subject → Chapter → Level flow मध्ये हिंदीचे 25 starter questions प्रति इयत्ता उपलब्ध आहेत.
