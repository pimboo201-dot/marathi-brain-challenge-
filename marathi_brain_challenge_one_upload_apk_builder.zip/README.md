# मराठी बुद्धीचाचणी — V2 Starter Project

Phone-first Marathi quiz platform starter.

## Included
- Player web/PWA UI
- Mobile Admin panel UI
- Add/Edit/Delete questions
- CSV import/export
- Local fallback data
- Firebase config placeholders
- Firestore security rules starter
- AdMob integration plan/placeholders
- Android packaging instructions

## Run on phone
Upload `player/` and `admin/` folders to any static HTTPS host, then open the URL on Android Chrome. Use Add to Home Screen.

## Firebase
1. Create a Firebase project.
2. Enable Authentication > Email/Password.
3. Create Firestore Database.
4. Copy your Firebase Web config into `player/firebase-config.js` and `admin/firebase-config.js`.
5. Deploy Firestore rules from `firebase/firestore.rules`.
6. Create an admin user in Firebase Authentication. Add its UID to the `admins` collection with document ID equal to the UID.

## AdMob
AdMob requires an Android native wrapper/build. This starter includes ad placeholders and a production integration checklist; replace test IDs with your own IDs before release.

## Important
This ZIP is source code, not a signed APK/AAB. A Play Store release needs your package name, signing key, Firebase config and AdMob IDs.

## V3 Player features
- Category-wise Quiz selection before playing
- Difficulty levels: Easy, Medium, Hard
- Coin rewards: Easy +5, Medium +10, Hard +20 per correct answer
- Daily Quiz completion bonus: +25 Coins
- Perfect Quiz bonus: +50 Coins
- 3-correct-answer streak bonus: +10 Coins
- Hint: costs 30 Coins and removes two wrong options

Coins are currently stored locally on the player's device using localStorage. For a production leaderboard/account-based reward system, store user profiles and coin balances in Firebase with secure server-side validation.
