# Marathi Brain Challenge — One Upload APK Builder

फोनवरून GitHub Actions वापरून Debug APK build करण्यासाठी.

## Upload
Repository मध्ये खालील दोन गोष्टी ठेवा:
- `v2-project.zip`
- `.github/workflows/build-apk.yml`

## Build
GitHub → Actions → Build Marathi Brain Challenge APK → Run workflow.

Build पूर्ण झाल्यावर Artifacts मधून `Marathi-Brain-Challenge-APK` डाउनलोड करा.
ZIP extract करून `app-debug.apk` install करा.

Play Store साठी हा Debug APK नाही; नंतर signed Release AAB तयार करावा लागेल.
