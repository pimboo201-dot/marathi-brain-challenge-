import { firebaseConfig } from './firebase-config.js';
import { initializeApp } from 'https://www.gstatic.com/firebasejs/12.1.0/firebase-app.js';
import { getFirestore, collection, getDocs, query, where } from 'https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js';

const demo=[
{category:'महाराष्ट्र सामान्यज्ञान',question:'महाराष्ट्राची राजधानी कोणती?',options:['पुणे','मुंबई','नागपूर','नाशिक'],answer:1,difficulty:'Easy'},
{category:'भारत सामान्यज्ञान',question:'भारताचा राष्ट्रीय प्राणी कोणता?',options:['सिंह','हत्ती','वाघ','मोर'],answer:2,difficulty:'Easy'},
{category:'विज्ञान',question:'पाण्याचे रासायनिक सूत्र काय आहे?',options:['CO2','O2','H2O','NaCl'],answer:2,difficulty:'Easy'},
{category:'इतिहास',question:'छत्रपती शिवाजी महाराजांचा जन्म कुठे झाला?',options:['रायगड','शिवनेरी','प्रतापगड','सिंधुदुर्ग'],answer:1,difficulty:'Medium'},
{category:'भूगोल',question:'सूर्य कोणत्या दिशेला उगवतो?',options:['पश्चिम','उत्तर','दक्षिण','पूर्व'],answer:3,difficulty:'Easy'},
{category:'तर्कशक्ती',question:'2, 4, 6, 8 नंतर कोणता अंक येईल?',options:['9','10','11','12'],answer:1,difficulty:'Easy'},
{category:'मराठी भाषा',question:'“सुंदर” या शब्दाचा विरुद्धार्थी शब्द कोणता?',options:['चांगला','कुरूप','मोठा','लहान'],answer:1,difficulty:'Easy'},
{category:'विज्ञान',question:'मानवी शरीरात रक्त पंप करणारा अवयव कोणता?',options:['फुफ्फुसे','मेंदू','हृदय','यकृत'],answer:2,difficulty:'Medium'}
];
let questions=[...demo],game=[],idx=0,correct=0,answered=false,coins=Number(localStorage.getItem('coins')||0),selectedCategory='',selectedDifficulty='',quizMode='category',coinsEarned=0,streak=0,hintUsed=false;
const $=id=>document.getElementById(id); $('coins').textContent=coins;

async function loadOnline(){try{const app=initializeApp(firebaseConfig);const db=getFirestore(app);const q=query(collection(db,'questions'),where('published','==',true));const snap=await getDocs(q);const online=snap.docs.map(d=>({id:d.id,...d.data()}));if(online.length)questions=online}catch(e){console.log('Offline/demo mode')}}loadOnline();

window.goHome=()=>show('homeScreen'); window.showAbout=()=>show('infoScreen');
window.showScores=()=>alert(`🏆 तुमचे Coins: ${coins}\n\nयोग्य उत्तरांवर Coins मिळतात.\nEasy +5 • Medium +10 • Hard +20\nDaily Bonus +25 • Perfect Bonus +50`);
window.openCategories=()=>{renderCategories();show('categoryScreen')};
function renderCategories(){const counts={};questions.forEach(q=>{counts[q.category]=(counts[q.category]||0)+1});const list=$('categoryList');const cats=Object.keys(counts);list.innerHTML=cats.length?cats.map(c=>`<button onclick="selectCategory('${encodeURIComponent(c)}')"><span class="cat-icon">${iconFor(c)}</span><div><b>${esc(c)}</b><small>${counts[c]} प्रश्न उपलब्ध</small></div><strong>→</strong></button>`).join(''):'<div class="empty">सध्या प्रश्न उपलब्ध नाहीत.</div>'}
window.selectCategory=(encoded)=>{selectedCategory=decodeURIComponent(encoded);$('selectedCategoryTitle').textContent=selectedCategory;show('levelScreen')};
window.startCategoryLevel=(level)=>{selectedDifficulty=level;quizMode='category';const pool=questions.filter(q=>q.category===selectedCategory && normalizeDifficulty(q.difficulty)===level);startGame(pool,Math.min(pool.length,10))};
window.startDaily=()=>{quizMode='daily';selectedCategory='Daily Quiz';selectedDifficulty='Mixed';const pool=[...questions].sort(()=>Math.random()-.5);startGame(pool,Math.min(pool.length,5))};
function startGame(pool,n){if(!pool.length){alert(`या Category मध्ये ${selectedDifficulty} Level चे प्रश्न सध्या उपलब्ध नाहीत.`);return}game=[...pool].sort(()=>Math.random()-.5).slice(0,n);idx=0;correct=0;coinsEarned=0;streak=0;show('quizScreen');render()}
function show(id){document.querySelectorAll('.screen').forEach(x=>x.classList.remove('active'));$(id).classList.add('active');scrollTo(0,0)}
function render(){answered=false;hintUsed=false;const q=game[idx];$('counter').textContent=`प्रश्न ${idx+1}/${game.length}`;$('score').textContent=`बरोबर: ${correct} • 🪙 +${coinsEarned}`;$('bar').style.width=((idx)/game.length*100)+'%';$('cat').textContent=`${q.category} • ${difficultyLabel(q.difficulty)}`;$('question').textContent=q.question;$('answers').innerHTML='';q.options.forEach((a,i)=>{let b=document.createElement('button');b.className='answer';b.textContent=`${'ABCD'[i]}) ${a}`;b.onclick=()=>answer(i,b);$('answers').appendChild(b)});$('next').classList.add('hidden');$('hint').disabled=coins<30}
function answer(i,b){if(answered)return;answered=true;const q=game[idx];document.querySelectorAll('.answer').forEach((x,j)=>{if(j===q.answer)x.classList.add('correct')});if(i===q.answer){b.classList.add('correct');correct++;streak++;const reward=coinValue(q.difficulty);coins+=reward;coinsEarned+=reward;if(streak===3){coins+=10;coinsEarned+=10}}else{b.classList.add('wrong');streak=0}saveCoins();$('score').textContent=`बरोबर: ${correct} • 🪙 +${coinsEarned}`;$('next').classList.remove('hidden');$('hint').disabled=true}
$('hint').onclick=()=>{if(answered||hintUsed||coins<30)return;const q=game[idx];const wrong=[...document.querySelectorAll('.answer')].filter((_,i)=>i!==q.answer);if(wrong.length){wrong.sort(()=>Math.random()-.5).slice(0,2).forEach(b=>{b.disabled=true;b.style.opacity='.35'});coins-=30;saveCoins();hintUsed=true;$('hint').textContent='💡 Hint वापरला';$('hint').disabled=true}}
$('next').onclick=()=>{if(idx<game.length-1){idx++;render()}else finish()};
function finish(){let bonus=0;if(quizMode==='daily'){bonus+=25}if(correct===game.length){bonus+=50}if(bonus){coins+=bonus;coinsEarned+=bonus;saveCoins()}show('resultScreen');$('final').textContent=`${correct} / ${game.length}`;$('message').textContent=correct===game.length?'अप्रतिम! 🔥 सर्व प्रश्न बरोबर!':correct>=game.length*.7?'खूप छान! 👏':'पुन्हा खेळा आणि स्कोअर वाढवा. 💪';$('rewardResult').innerHTML=`🪙 या Quiz मधून मिळाले <b>+${coinsEarned} Coins</b>${quizMode==='daily'?'<br>📅 Daily Bonus समाविष्ट आहे.':''}`}
function saveCoins(){localStorage.setItem('coins',coins);$('coins').textContent=coins}
function coinValue(d){d=normalizeDifficulty(d);return d==='Easy'?5:d==='Medium'?10:20}
function normalizeDifficulty(d){const x=String(d||'Easy').toLowerCase();if(x==='medium'||x==='midium')return'Medium';if(x==='hard')return'Hard';return'Easy'}
function difficultyLabel(d){const n=normalizeDifficulty(d);return n==='Easy'?'Easy 🟢':n==='Medium'?'Medium 🟡':'Hard 🔴'}
function iconFor(c){if(c.includes('इतिहास'))return'🏛️';if(c.includes('विज्ञान'))return'🔬';if(c.includes('भूगोल'))return'🌍';if(c.includes('मराठी'))return'📖';if(c.includes('तर्क'))return'🧩';if(c.includes('भारत'))return'🇮🇳';if(c.includes('महाराष्ट्र'))return'🚩';return'🧠'}
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
$('home').onclick=goHome;
