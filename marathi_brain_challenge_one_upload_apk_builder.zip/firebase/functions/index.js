const { onSchedule } = require('firebase-functions/v2/scheduler');
const { logger } = require('firebase-functions');
const admin = require('firebase-admin');
const { XMLParser } = require('fast-xml-parser');

admin.initializeApp();
const db = admin.firestore();

const FEEDS = [
  'https://news.google.com/rss?hl=mr&gl=IN&ceid=IN:mr',
  'https://news.google.com/rss/headlines/section/topic/NATION?hl=mr&gl=IN&ceid=IN:mr',
  'https://news.google.com/rss/headlines/section/topic/SPORTS?hl=mr&gl=IN&ceid=IN:mr'
];

function cleanTitle(value='') {
  return String(value).replace(/\s+-\s+[^-]+$/, '').trim();
}

async function fetchFeed(url) {
  const response = await fetch(url, { headers: { 'User-Agent': 'MarathiBrainChallenge/6.0' } });
  if (!response.ok) throw new Error(`RSS ${response.status}`);
  const xml = await response.text();
  const parser = new XMLParser({ ignoreAttributes: false });
  const parsed = parser.parse(xml);
  const items = parsed?.rss?.channel?.item || [];
  return (Array.isArray(items) ? items : [items]).map(x => ({
    title: cleanTitle(x.title), link: x.link || '', pubDate: x.pubDate || ''
  })).filter(x => x.title);
}

exports.updateCurrentAffairs = onSchedule({ schedule: 'every 6 hours', timeZone: 'Asia/Kolkata', region: 'asia-south1' }, async () => {
  const all = [];
  for (const feed of FEEDS) {
    try { all.push(...await fetchFeed(feed)); } catch (e) { logger.warn(`Feed failed: ${feed}`, e); }
  }
  const unique = [...new Map(all.map(x => [x.title, x])).values()].slice(0, 100);
  if (unique.length < 20) throw new Error('Not enough current-affairs headlines fetched');

  const now = Date.now();
  const today = new Date(now).toLocaleDateString('mr-IN', { timeZone: 'Asia/Kolkata', day: '2-digit', month: '2-digit', year: 'numeric' });
  const batch = db.batch();

  // 25 live questions, each built from four fresh headlines. The correct answer is
  // always one of today's verified headlines; the remaining three are distractors.
  for (let i = 0; i < 25; i++) {
    const base = i * 4;
    const choices = [unique[base % unique.length], unique[(base + 1) % unique.length], unique[(base + 2) % unique.length], unique[(base + 3) % unique.length]];
    const correct = i % 4;
    const ref = db.collection('current_affairs').doc(`live-${i + 1}`);
    batch.set(ref, {
      category: 'चालू घडामोडी', chapter: 'Live • Auto Update',
      question: `आजच्या (${today}) ताज्या घडामोडींमध्ये खालीलपैकी कोणती बातमी नोंदली आहे?`,
      options: choices.map(x => x.title), answer: correct, difficulty: i < 9 ? 'Easy' : i < 18 ? 'Medium' : 'Hard',
      source: 'Google News RSS headlines', sourceUrl: choices[correct].link,
      published: true, updatedAt: now, newsDate: choices[correct].pubDate || today
    }, { merge: true });
  }
  await batch.commit();
  logger.info(`Current affairs updated: ${Math.min(unique.length, 100)} headlines → 25 quiz questions`);
});
