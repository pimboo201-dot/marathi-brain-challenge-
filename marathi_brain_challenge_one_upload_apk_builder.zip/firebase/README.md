## Firebase setup

Create:
- `questions` collection
- `admins` collection

For an admin user:
1. Firebase Authentication -> add Email/Password user.
2. Copy the user's UID.
3. Create Firestore document `admins/<UID>`, e.g. `{role:"admin"}`.

Question document example:
{
  "category":"महाराष्ट्र सामान्यज्ञान",
  "question":"महाराष्ट्राची राजधानी कोणती?",
  "options":["पुणे","मुंबई","नागपूर","नाशिक"],
  "answer":1,
  "difficulty":"Easy",
  "published":true,
  "createdAt": 1234567890
}

Deploy the supplied rules after testing.
